<?php
/**
 * footer template
 */
?>
</div>
<?php pixwell_amp_render_footer_ad(); ?>
<?php pixwell_amp_render_footer();  ?>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>